package csci.proj.lcs;

import java.util.Random;

public class StringGenerator {
	
	public StringGenerator() {
	}
	public String createString(char[] alphabet, int size, long seed){
		Random generator = new Random(seed);
		int alphabetSize = alphabet.length;
		StringBuilder result = new StringBuilder();
		for (int i = 0; i< size; i++){
			int j = generator.nextInt(alphabetSize);
			result.append(alphabet[j]);
		}
		return result.toString();
	}
	
	public static void main(String[] args){
		StringGenerator sg = new StringGenerator();
		char[] s = {'A', 'C', 'G','T'};
		String st = sg.createString(s, 10, 10);
		System.out.println(st);
	}
	
	
}
